# TradeWithDurga — Design System

## Overview
Premium dark glassmorphic trading mentorship platform. Steel-blue accent gradient, frosted glass cards, sophisticated trading interface. Dark-only mode for nocturnal traders.

## Color Palette

| Token              | OKLCH Values      | Hex Intent  | Purpose                      |
|:-------------------|:------------------|:------------|:-----------------------------|
| Background         | 0.08 0.01 240    | #0A0A0F     | Page background              |
| Surface            | 0.11 0.01 240    | #111118     | Cards, surfaces              |
| Surface Secondary  | 0.14 0.01 240    | #1A1A24     | Elevated surfaces            |
| Text               | 0.94 0.01 240    | #F0F0F5     | Primary text                 |
| Text Muted         | 0.53 0.02 240    | #8888A0     | Secondary text, labels       |
| Accent Primary     | 0.69 0.09 250    | #89AACC     | Gradient start (buttons, highlight) |
| Accent Secondary   | 0.52 0.12 245    | #4E85BF     | Gradient end, hover states   |
| Border             | 0.14 0.01 240    | #1E1E2A     | Card borders, dividers       |
| Success            | 0.49 0.24 264    | #4ADE80     | Positive results, gains      |
| Danger             | 0.62 0.22 29     | #F87171     | Losses, alerts, negative     |
| Warning            | 0.83 0.27 54     | #FBBF24     | Drawdown warnings            |
| Info               | 0.72 0.18 142    | #60A5FA     | Informational messages       |

## Typography

| Layer      | Font              | Weights    | Usage                                |
|:-----------|:------------------|:-----------|:-------------------------------------|
| Display    | Instrument Serif  | 400 Italic | Headlines, page titles, hero text    |
| Body       | DM Sans           | 300–700   | Body copy, form labels, UI text      |
| Mono       | Geist Mono        | 400       | Code, terminal, data tables          |

Type Scale: `text-xs` (10px) → `text-9xl` (96px). Headings use display italic; body uses 400–500 weight; interactive elements bold (600–700).

## Glassmorphism

All cards apply `.glass` utility:
- `backdrop-blur-md` (blur 12px)
- `bg-white/[0.03]` (3% opacity white)
- `border border-white/[0.08]` (8% opacity border)
- Hover: `bg-white/[0.05]` + `border-white/[0.12]` + `-translateY-0.5`

## Structural Zones

| Zone            | Treatment                                    | Depth      |
|:----------------|:---------------------------------------------|:-----------|
| Header / Nav    | `.glass` card with accent gradient top line | Elevated   |
| Sidebar         | `bg-sidebar` (0.10 L) with `.glass` items  | Subtle     |
| Content         | `bg-background` (0.08 L), `.glass` sections | Base       |
| Footer          | `bg-background` with top border              | Minimal    |
| Modal / Overlay | `bg-background/80` with backdrop-blur       | Modal      |

## Accent Gradient

Linear gradient (135deg): `#89AACC` → `#4E85BF`. Used on:
- CTA buttons (primary action)
- Progress bars & indicators
- Text highlights (background-clip: text)
- Border accents on premium cards
- Hover states on interactive elements

## Interaction Patterns

| Element           | Default State              | Hover State                      | Active State                  |
|:------------------|:---------------------------|:---------------------------------|:------------------------------|
| Primary Button    | gradient-accent bg, glow   | scale-105, shadow-elevated      | scale-95, shadow-subtle       |
| Glass Card        | .glass                     | bg-white/[0.05], -translateY-1  | ring-1 ring-accent/30         |
| Input Field       | .glass, bg-white/[0.02]    | bg-white/[0.04], border-accent  | border-accent/60, ring-accent |
| Link              | text-muted                 | text-foreground, underline       | text-accent                   |

## Motion & Animation

- **Entrance**: Fade + slide (y: 8px → 0, 0.2s ease-out)
- **Hover**: Smooth scale (0.2s cubic-bezier)
- **Load**: `.animate-pulse-glow` on cards, charts
- **Transitions**: `.transition-smooth` (0.3s cubic-bezier(0.4, 0, 0.2, 1))
- **Float**: `.animate-float` (8px vertical, 3s infinite)

## Semantic Colors in Context

| Semantic   | Color         | Usage Examples                                  |
|:-----------|:--------------|:------------------------------------------------|
| Success    | #4ADE80       | Winning trades, gains, "Online", checkmarks    |
| Danger     | #F87171       | Losing trades, DD breach, errors, delete       |
| Warning    | #FBBF24       | DD caution zones (60–80%), alerts               |
| Info       | #60A5FA       | Session reminders, notifications, Q&A badges   |

## Component Defaults

- **Buttons**: Rounded-lg (12px), glass or gradient backgrounds, 3.5rem h, semibold text
- **Inputs**: Rounded-lg, glass style, no ring on focus (use border-accent instead)
- **Tables**: No borders, glass rows on hover, striped alternation via bg-white/[0.01]
- **Cards**: .glass, rounded-xl (20px), p-6, subtle shadows
- **Modals**: Centered, fixed inset, bg-background/80 backdrop, .glass inner card

## Reserved Color Uses

- Never use saturated reds, greens, or yellows
- Accent gradient reserved for CTAs and primary highlights only
- Border colors always from `--border` token (0.14 L)
- Text must use `--foreground` or `--muted-foreground` (never raw white/grey)

## Contrast Assurance

All foreground/background pairs meet WCAG AAA:
- Text on background: ΔL ≥ 0.75
- Interactive elements: ΔL ≥ 0.50 on hover
- Focus states: ring-accent with ≥ 3px width

## Files Generated

- `src/frontend/src/index.css` — OKLCH CSS variables, @font-face declarations, utility classes
- `src/frontend/tailwind.config.js` — Theme extensions (colors, shadows, animations, fonts)
- `src/frontend/public/assets/fonts/` — Instrument Serif Italic, DM Sans, Geist Mono
- Design preview: `.platform/design/preview-*.jpg`
