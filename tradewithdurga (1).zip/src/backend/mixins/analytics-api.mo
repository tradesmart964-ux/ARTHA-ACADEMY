import List "mo:core/List";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Common "../types/common";
import AnalyticsTypes "../types/analytics";
import AnalyticsLib "../lib/analytics";

mixin (
  accessControlState : AccessControl.AccessControlState,
  uploads : List.List<AnalyticsTypes.DailyUpload>,
  backtests : List.List<AnalyticsTypes.BacktestSession>,
  payouts : List.List<AnalyticsTypes.Payout>,
  consistencyRecords : List.List<AnalyticsTypes.ConsistencyRecord>,
) {
  public shared ({ caller }) func createUpload(input : AnalyticsTypes.CreateUploadInput) : async AnalyticsTypes.DailyUploadPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    AnalyticsLib.createUpload(uploads, caller, input);
  };

  public query ({ caller }) func listUploads() : async [AnalyticsTypes.DailyUploadPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    AnalyticsLib.listUploads(uploads, caller);
  };

  public query ({ caller }) func listAllUploads() : async [AnalyticsTypes.DailyUploadPublic] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can list all uploads");
    };
    AnalyticsLib.listAllUploads(uploads);
  };

  public shared ({ caller }) func createBacktest(input : AnalyticsTypes.CreateBacktestInput) : async AnalyticsTypes.BacktestSessionPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    AnalyticsLib.createBacktest(backtests, caller, input);
  };

  public query ({ caller }) func listBacktests() : async [AnalyticsTypes.BacktestSessionPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    AnalyticsLib.listBacktests(backtests, caller);
  };

  public shared ({ caller }) func createPayout(input : AnalyticsTypes.CreatePayoutInput) : async AnalyticsTypes.PayoutPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    AnalyticsLib.createPayout(payouts, caller, input);
  };

  public query ({ caller }) func listPayouts() : async [AnalyticsTypes.PayoutPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    AnalyticsLib.listPayouts(payouts, caller);
  };

  public query ({ caller }) func getConsistency() : async ?AnalyticsTypes.ConsistencyRecord {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    AnalyticsLib.getConsistency(consistencyRecords, caller);
  };
};
