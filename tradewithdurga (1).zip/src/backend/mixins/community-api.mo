import List "mo:core/List";
import Map "mo:core/Map";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Common "../types/common";
import CommunityTypes "../types/community";
import CommunityLib "../lib/community";

mixin (
  accessControlState : AccessControl.AccessControlState,
  forumThreads : List.List<CommunityTypes.ForumThread>,
  forumReplies : List.List<CommunityTypes.ForumReply>,
  bookings : List.List<CommunityTypes.CallBooking>,
  announcements : List.List<CommunityTypes.Announcement>,
  liveSessions : List.List<CommunityTypes.LiveSession>,
  mentorComments : Map.Map<Text, CommunityTypes.MentorComment>,
) {
  public shared ({ caller }) func createForumThread(input : CommunityTypes.CreateForumThreadInput) : async CommunityTypes.ForumThreadPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.createForumThread(forumThreads, caller, input);
  };

  public query ({ caller }) func listForumThreads() : async [CommunityTypes.ForumThreadPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.listForumThreads(forumThreads);
  };

  public shared ({ caller }) func createForumReply(input : CommunityTypes.CreateForumReplyInput) : async CommunityTypes.ForumReplyPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.createForumReply(forumReplies, caller, input);
  };

  public query ({ caller }) func listRepliesByThread(threadId : Text) : async [CommunityTypes.ForumReplyPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.listRepliesByThread(forumReplies, threadId);
  };

  public shared ({ caller }) func createBooking(input : CommunityTypes.CreateBookingInput) : async CommunityTypes.CallBookingPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.createBooking(bookings, caller, input);
  };

  public query ({ caller }) func listBookings() : async [CommunityTypes.CallBookingPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.listBookings(bookings, caller);
  };

  public shared ({ caller }) func createAnnouncement(input : CommunityTypes.CreateAnnouncementInput) : async CommunityTypes.AnnouncementPublic {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can create announcements");
    };
    CommunityLib.createAnnouncement(announcements, caller, input);
  };

  public query ({ caller }) func listAnnouncements() : async [CommunityTypes.AnnouncementPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.listAnnouncements(announcements);
  };

  public query ({ caller }) func listLiveSessions() : async [CommunityTypes.LiveSessionPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.listLiveSessions(liveSessions);
  };

  public shared ({ caller }) func createLiveSession(input : CommunityTypes.CreateLiveSessionInput) : async CommunityTypes.LiveSessionPublic {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can create live sessions");
    };
    CommunityLib.createLiveSession(liveSessions, caller, input);
  };

  public shared ({ caller }) func addMentorComment(tradeId : Text, comment : Text) : async CommunityTypes.MentorCommentPublic {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add mentor comments");
    };
    CommunityLib.createMentorComment(mentorComments, caller, tradeId, comment);
  };

  public query ({ caller }) func getMentorComment(tradeId : Text) : async ?CommunityTypes.MentorCommentPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    CommunityLib.getMentorComment(mentorComments, tradeId);
  };
};
