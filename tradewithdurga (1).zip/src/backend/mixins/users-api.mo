import Map "mo:core/Map";
import Principal "mo:core/Principal";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Common "../types/common";
import UserTypes "../types/users";
import UserLib "../lib/users";

mixin (
  accessControlState : AccessControl.AccessControlState,
  users : Map.Map<Common.UserId, UserTypes.User>,
  emailIndex : Map.Map<Text, Common.UserId>,
) {
  public shared ({ caller }) func createUser(input : UserTypes.CreateUserInput) : async UserTypes.UserPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #admin)) {
      Runtime.trap("Unauthorized: Only admins can create users");
    };
    UserLib.createUser(users, emailIndex, caller, input);
  };

  public query ({ caller }) func getUser(id : Common.UserId) : async ?UserTypes.UserPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    // Admin can see any user; users can only see themselves
    if (not AccessControl.isAdmin(accessControlState, caller) and not Principal.equal(caller, id)) {
      Runtime.trap("Unauthorized: Can only view your own profile");
    };
    UserLib.getUser(users, id);
  };

  public query ({ caller }) func getCallerUserProfile() : async ?UserTypes.UserPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    UserLib.getUser(users, caller);
  };

  public shared ({ caller }) func updateUser(input : UserTypes.UpdateUserInput) : async ?UserTypes.UserPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    UserLib.updateUser(users, caller, input);
  };

  public query ({ caller }) func listUsers() : async [UserTypes.UserPublic] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can list all users");
    };
    UserLib.listUsers(users);
  };

  public shared ({ caller }) func updateUserPlan(userId : Common.UserId, plan : Common.Plan) : async ?UserTypes.UserPublic {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can update user plans");
    };
    switch (users.get(userId)) {
      case (?user) {
        user.plan := plan;
        ?UserLib.toPublic(user);
      };
      case null null;
    };
  };

  public shared ({ caller }) func seedInitialUsers() : async () {
    // Allow only once — idempotent call (check done inside seedUsers)
    let adminId = Principal.fromText("aaaaa-aa");
    let studentId = Principal.fromText("2vxsx-fae");
    UserLib.seedUsers(users, emailIndex, adminId, studentId);
  };
};
