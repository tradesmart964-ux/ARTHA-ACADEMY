import List "mo:core/List";
import Map "mo:core/Map";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Common "../types/common";
import TradingTypes "../types/trading";
import TradingLib "../lib/trading";

mixin (
  accessControlState : AccessControl.AccessControlState,
  accounts : Map.Map<Text, TradingTypes.TradingAccount>,
  trades : List.List<TradingTypes.Trade>,
) {
  public shared ({ caller }) func createAccount(input : TradingTypes.CreateAccountInput) : async TradingTypes.TradingAccountPublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    TradingLib.createAccount(accounts, caller, input);
  };

  public query ({ caller }) func listAccounts() : async [TradingTypes.TradingAccountPublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    TradingLib.listAccounts(accounts, caller);
  };

  public shared ({ caller }) func createTrade(input : TradingTypes.CreateTradeInput) : async TradingTypes.TradePublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    TradingLib.createTrade(trades, caller, input);
  };

  public query ({ caller }) func getTrade(id : Text) : async ?TradingTypes.TradePublic {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    TradingLib.getTrade(trades, id);
  };

  public query ({ caller }) func listTrades() : async [TradingTypes.TradePublic] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    TradingLib.listTrades(trades, caller);
  };

  public shared ({ caller }) func deleteTrade(id : Text) : async Bool {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized");
    };
    TradingLib.deleteTrade(trades, id, caller);
  };

  public query ({ caller }) func listAllTrades() : async [TradingTypes.TradePublic] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can list all trades");
    };
    TradingLib.listAllTrades(trades);
  };
};
