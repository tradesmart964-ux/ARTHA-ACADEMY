import Map "mo:core/Map";
import List "mo:core/List";
import Time "mo:core/Time";
import Principal "mo:core/Principal";
import Common "../types/common";
import Types "../types/users";

module {
  public func toPublic(user : Types.User) : Types.UserPublic {
    {
      id = user.id;
      name = user.name;
      email = user.email;
      role = user.role;
      plan = user.plan;
      avatar = user.avatar;
      bio = user.bio;
      phone = user.phone;
      country = user.country;
      timezone = user.timezone;
      experience = user.experience;
      createdAt = user.createdAt;
    };
  };

  public func createUser(
    users : Map.Map<Common.UserId, Types.User>,
    emailIndex : Map.Map<Text, Common.UserId>,
    id : Common.UserId,
    input : Types.CreateUserInput,
  ) : Types.UserPublic {
    let user : Types.User = {
      id = id;
      var name = input.name;
      email = input.email;
      var passwordHash = input.passwordHash;
      var role = input.role;
      var plan = input.plan;
      var avatar = null;
      var bio = null;
      var phone = null;
      var country = null;
      var timezone = null;
      var experience = null;
      createdAt = Time.now();
    };
    users.add(id, user);
    emailIndex.add(input.email, id);
    toPublic(user);
  };

  public func getUser(
    users : Map.Map<Common.UserId, Types.User>,
    id : Common.UserId,
  ) : ?Types.UserPublic {
    switch (users.get(id)) {
      case (?user) ?toPublic(user);
      case null null;
    };
  };

  public func getUserByEmail(
    users : Map.Map<Common.UserId, Types.User>,
    emailIndex : Map.Map<Text, Common.UserId>,
    email : Text,
  ) : ?Types.UserPublic {
    switch (emailIndex.get(email)) {
      case (?id) {
        switch (users.get(id)) {
          case (?user) ?toPublic(user);
          case null null;
        };
      };
      case null null;
    };
  };

  public func updateUser(
    users : Map.Map<Common.UserId, Types.User>,
    id : Common.UserId,
    input : Types.UpdateUserInput,
  ) : ?Types.UserPublic {
    switch (users.get(id)) {
      case (?user) {
        switch (input.name) {
          case (?n) { user.name := n };
          case null {};
        };
        switch (input.avatar) {
          case (?a) { user.avatar := ?a };
          case null {};
        };
        switch (input.bio) {
          case (?b) { user.bio := ?b };
          case null {};
        };
        switch (input.phone) {
          case (?p) { user.phone := ?p };
          case null {};
        };
        switch (input.country) {
          case (?c) { user.country := ?c };
          case null {};
        };
        switch (input.timezone) {
          case (?tz) { user.timezone := ?tz };
          case null {};
        };
        switch (input.experience) {
          case (?e) { user.experience := ?e };
          case null {};
        };
        ?toPublic(user);
      };
      case null null;
    };
  };

  public func listUsers(
    users : Map.Map<Common.UserId, Types.User>,
  ) : [Types.UserPublic] {
    let result = List.empty<Types.UserPublic>();
    for ((_, u) in users.entries()) {
      result.add(toPublic(u));
    };
    result.toArray();
  };

  public func seedUsers(
    users : Map.Map<Common.UserId, Types.User>,
    emailIndex : Map.Map<Text, Common.UserId>,
    adminId : Common.UserId,
    studentId : Common.UserId,
  ) : () {
    // Only seed if not already present
    if (emailIndex.containsKey("you@example.com")) {
      return;
    };
    let adminUser : Types.User = {
      id = adminId;
      var name = "Durga";
      email = "you@example.com";
      var passwordHash = "seeded-admin";
      var role = #admin;
      var plan = #platinum;
      var avatar = null;
      var bio = ?"Professional Forex Trader & Educator with 7 years of live trading experience.";
      var phone = null;
      var country = ?"India";
      var timezone = ?"Asia/Kolkata";
      var experience = ?"expert";
      createdAt = Time.now();
    };
    let studentUser : Types.User = {
      id = studentId;
      var name = "Demo Student";
      email = "student@example.com";
      var passwordHash = "seeded-student";
      var role = #student;
      var plan = #gold;
      var avatar = null;
      var bio = null;
      var phone = null;
      var country = ?"India";
      var timezone = ?"Asia/Kolkata";
      var experience = ?"beginner";
      createdAt = Time.now();
    };
    users.add(adminId, adminUser);
    emailIndex.add("you@example.com", adminId);
    users.add(studentId, studentUser);
    emailIndex.add("student@example.com", studentId);
  };
};
