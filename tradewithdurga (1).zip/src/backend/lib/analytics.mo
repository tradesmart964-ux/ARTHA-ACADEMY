import List "mo:core/List";
import Time "mo:core/Time";
import Principal "mo:core/Principal";
import Common "../types/common";
import AnalyticsTypes "../types/analytics";

module {
  public func toUploadPublic(u : AnalyticsTypes.DailyUpload) : AnalyticsTypes.DailyUploadPublic {
    {
      id = u.id;
      userId = u.userId;
      accountId = u.accountId;
      tradingDate = u.tradingDate;
      csvUrl = u.csvUrl;
      totalTrades = u.totalTrades;
      winCount = u.winCount;
      lossCount = u.lossCount;
      grossPnl = u.grossPnl;
      netPnl = u.netPnl;
      dailyDD = u.dailyDD;
      maxDD = u.maxDD;
      avgRiskPercent = u.avgRiskPercent;
      riskBreachCount = u.riskBreachCount;
      dailyDDBreached = u.dailyDDBreached;
      maxDDBreached = u.maxDDBreached;
      parsedData = u.parsedData;
      createdAt = u.createdAt;
    };
  };

  public func toBacktestPublic(b : AnalyticsTypes.BacktestSession) : AnalyticsTypes.BacktestSessionPublic {
    {
      id = b.id;
      userId = b.userId;
      name = b.name;
      pair = b.pair;
      timeframe = b.timeframe;
      startingBalance = b.startingBalance;
      riskPerTrade = b.riskPerTrade;
      dateRangeStart = b.dateRangeStart;
      dateRangeEnd = b.dateRangeEnd;
      totalTrades = b.totalTrades;
      winRate = b.winRate;
      netPnl = b.netPnl;
      maxDD = b.maxDD;
      profitFactor = b.profitFactor;
      avgRR = b.avgRR;
      tradeLog = b.tradeLog;
      createdAt = b.createdAt;
    };
  };

  public func toPayoutPublic(p : AnalyticsTypes.Payout) : AnalyticsTypes.PayoutPublic {
    {
      id = p.id;
      userId = p.userId;
      accountId = p.accountId;
      payoutDate = p.payoutDate;
      amount = p.amount;
      currency = p.currency;
      payoutType = p.payoutType;
      profitSplitPct = p.profitSplitPct;
      actualReceived = p.actualReceived;
      status = p.status;
      paymentMethod = p.paymentMethod;
      proofUrl = p.proofUrl;
      notes = p.notes;
      createdAt = p.createdAt;
    };
  };

  public func createUpload(
    uploads : List.List<AnalyticsTypes.DailyUpload>,
    userId : Common.UserId,
    input : AnalyticsTypes.CreateUploadInput,
  ) : AnalyticsTypes.DailyUploadPublic {
    let id = "upload-" # userId.toText() # "-" # Time.now().toText();
    let upload : AnalyticsTypes.DailyUpload = {
      id = id;
      userId = userId;
      var accountId = input.accountId;
      tradingDate = input.tradingDate;
      var csvUrl = input.csvUrl;
      var totalTrades = input.totalTrades;
      var winCount = input.winCount;
      var lossCount = input.lossCount;
      var grossPnl = input.grossPnl;
      var netPnl = input.netPnl;
      var dailyDD = input.dailyDD;
      var maxDD = input.maxDD;
      var avgRiskPercent = input.avgRiskPercent;
      var riskBreachCount = input.riskBreachCount;
      var dailyDDBreached = input.dailyDDBreached;
      var maxDDBreached = input.maxDDBreached;
      var parsedData = input.parsedData;
      createdAt = Time.now();
    };
    uploads.add(upload);
    toUploadPublic(upload);
  };

  public func listUploads(
    uploads : List.List<AnalyticsTypes.DailyUpload>,
    userId : Common.UserId,
  ) : [AnalyticsTypes.DailyUploadPublic] {
    let result = List.empty<AnalyticsTypes.DailyUploadPublic>();
    for (u in uploads.values()) {
      if (Principal.equal(u.userId, userId)) {
        result.add(toUploadPublic(u));
      };
    };
    result.toArray();
  };

  public func listAllUploads(
    uploads : List.List<AnalyticsTypes.DailyUpload>,
  ) : [AnalyticsTypes.DailyUploadPublic] {
    let result = List.empty<AnalyticsTypes.DailyUploadPublic>();
    for (u in uploads.values()) {
      result.add(toUploadPublic(u));
    };
    result.toArray();
  };

  public func createBacktest(
    backtests : List.List<AnalyticsTypes.BacktestSession>,
    userId : Common.UserId,
    input : AnalyticsTypes.CreateBacktestInput,
  ) : AnalyticsTypes.BacktestSessionPublic {
    let id = "bt-" # userId.toText() # "-" # Time.now().toText();
    let session : AnalyticsTypes.BacktestSession = {
      id = id;
      userId = userId;
      var name = input.name;
      var pair = input.pair;
      var timeframe = input.timeframe;
      startingBalance = input.startingBalance;
      var riskPerTrade = input.riskPerTrade;
      var dateRangeStart = input.dateRangeStart;
      var dateRangeEnd = input.dateRangeEnd;
      var totalTrades = input.totalTrades;
      var winRate = input.winRate;
      var netPnl = input.netPnl;
      var maxDD = input.maxDD;
      var profitFactor = input.profitFactor;
      var avgRR = input.avgRR;
      var tradeLog = input.tradeLog;
      createdAt = Time.now();
    };
    backtests.add(session);
    toBacktestPublic(session);
  };

  public func listBacktests(
    backtests : List.List<AnalyticsTypes.BacktestSession>,
    userId : Common.UserId,
  ) : [AnalyticsTypes.BacktestSessionPublic] {
    let result = List.empty<AnalyticsTypes.BacktestSessionPublic>();
    for (b in backtests.values()) {
      if (Principal.equal(b.userId, userId)) {
        result.add(toBacktestPublic(b));
      };
    };
    result.toArray();
  };

  public func createPayout(
    payouts : List.List<AnalyticsTypes.Payout>,
    userId : Common.UserId,
    input : AnalyticsTypes.CreatePayoutInput,
  ) : AnalyticsTypes.PayoutPublic {
    let id = "payout-" # userId.toText() # "-" # Time.now().toText();
    let payout : AnalyticsTypes.Payout = {
      id = id;
      userId = userId;
      var accountId = input.accountId;
      payoutDate = input.payoutDate;
      amount = input.amount;
      currency = input.currency;
      payoutType = input.payoutType;
      var profitSplitPct = input.profitSplitPct;
      var actualReceived = null;
      var status = #pending;
      var paymentMethod = input.paymentMethod;
      var proofUrl = null;
      var notes = input.notes;
      createdAt = Time.now();
    };
    payouts.add(payout);
    toPayoutPublic(payout);
  };

  public func listPayouts(
    payouts : List.List<AnalyticsTypes.Payout>,
    userId : Common.UserId,
  ) : [AnalyticsTypes.PayoutPublic] {
    let result = List.empty<AnalyticsTypes.PayoutPublic>();
    for (p in payouts.values()) {
      if (Principal.equal(p.userId, userId)) {
        result.add(toPayoutPublic(p));
      };
    };
    result.toArray();
  };

  public func getConsistency(
    consistencyRecords : List.List<AnalyticsTypes.ConsistencyRecord>,
    userId : Common.UserId,
  ) : ?AnalyticsTypes.ConsistencyRecord {
    // Return the most recent consistency record for user
    var latest : ?AnalyticsTypes.ConsistencyRecord = null;
    for (r in consistencyRecords.values()) {
      if (Principal.equal(r.userId, userId)) {
        switch (latest) {
          case null { latest := ?r };
          case (?prev) {
            if (r.createdAt > prev.createdAt) {
              latest := ?r;
            };
          };
        };
      };
    };
    latest;
  };
};
