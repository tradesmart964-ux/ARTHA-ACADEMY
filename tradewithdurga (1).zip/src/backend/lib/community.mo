import List "mo:core/List";
import Map "mo:core/Map";
import Time "mo:core/Time";
import Principal "mo:core/Principal";
import Common "../types/common";
import CommunityTypes "../types/community";

module {
  public func toThreadPublic(t : CommunityTypes.ForumThread) : CommunityTypes.ForumThreadPublic {
    {
      id = t.id;
      userId = t.userId;
      title = t.title;
      body = t.body;
      category = t.category;
      imageUrl = t.imageUrl;
      solved = t.solved;
      likes = t.likes;
      bookmarks = t.bookmarks;
      createdAt = t.createdAt;
    };
  };

  public func toReplyPublic(r : CommunityTypes.ForumReply) : CommunityTypes.ForumReplyPublic {
    {
      id = r.id;
      threadId = r.threadId;
      userId = r.userId;
      body = r.body;
      parentId = r.parentId;
      createdAt = r.createdAt;
    };
  };

  public func toBookingPublic(b : CommunityTypes.CallBooking) : CommunityTypes.CallBookingPublic {
    {
      id = b.id;
      userId = b.userId;
      scheduledAt = b.scheduledAt;
      duration = b.duration;
      topic = b.topic;
      notes = b.notes;
      status = b.status;
      meetLink = b.meetLink;
      createdAt = b.createdAt;
    };
  };

  public func toAnnouncementPublic(a : CommunityTypes.Announcement) : CommunityTypes.AnnouncementPublic {
    {
      id = a.id;
      adminId = a.adminId;
      title = a.title;
      body = a.body;
      plan = a.plan;
      emailSent = a.emailSent;
      sentAt = a.sentAt;
    };
  };

  public func toSessionPublic(s : CommunityTypes.LiveSession) : CommunityTypes.LiveSessionPublic {
    {
      id = s.id;
      title = s.title;
      description = s.description;
      scheduledAt = s.scheduledAt;
      joinUrl = s.joinUrl;
      recordingUrl = s.recordingUrl;
      tags = s.tags;
      status = s.status;
      createdAt = s.createdAt;
    };
  };

  public func createForumThread(
    threads : List.List<CommunityTypes.ForumThread>,
    userId : Common.UserId,
    input : CommunityTypes.CreateForumThreadInput,
  ) : CommunityTypes.ForumThreadPublic {
    let id = "thread-" # userId.toText() # "-" # Time.now().toText();
    let thread : CommunityTypes.ForumThread = {
      id = id;
      userId = userId;
      var title = input.title;
      var body = input.body;
      var category = input.category;
      var imageUrl = input.imageUrl;
      var solved = false;
      var likes = 0;
      var bookmarks = 0;
      createdAt = Time.now();
    };
    threads.add(thread);
    toThreadPublic(thread);
  };

  public func listForumThreads(
    threads : List.List<CommunityTypes.ForumThread>,
  ) : [CommunityTypes.ForumThreadPublic] {
    let result = List.empty<CommunityTypes.ForumThreadPublic>();
    for (t in threads.values()) {
      result.add(toThreadPublic(t));
    };
    result.toArray();
  };

  public func getForumThread(
    threads : List.List<CommunityTypes.ForumThread>,
    id : Text,
  ) : ?CommunityTypes.ForumThreadPublic {
    switch (threads.find(func(t) = t.id == id)) {
      case (?t) ?toThreadPublic(t);
      case null null;
    };
  };

  public func createForumReply(
    replies : List.List<CommunityTypes.ForumReply>,
    userId : Common.UserId,
    input : CommunityTypes.CreateForumReplyInput,
  ) : CommunityTypes.ForumReplyPublic {
    let id = "reply-" # userId.toText() # "-" # Time.now().toText();
    let reply : CommunityTypes.ForumReply = {
      id = id;
      threadId = input.threadId;
      userId = userId;
      var body = input.body;
      parentId = input.parentId;
      createdAt = Time.now();
    };
    replies.add(reply);
    toReplyPublic(reply);
  };

  public func listRepliesByThread(
    replies : List.List<CommunityTypes.ForumReply>,
    threadId : Text,
  ) : [CommunityTypes.ForumReplyPublic] {
    let result = List.empty<CommunityTypes.ForumReplyPublic>();
    for (r in replies.values()) {
      if (r.threadId == threadId) {
        result.add(toReplyPublic(r));
      };
    };
    result.toArray();
  };

  public func createBooking(
    bookings : List.List<CommunityTypes.CallBooking>,
    userId : Common.UserId,
    input : CommunityTypes.CreateBookingInput,
  ) : CommunityTypes.CallBookingPublic {
    let id = "booking-" # userId.toText() # "-" # Time.now().toText();
    let booking : CommunityTypes.CallBooking = {
      id = id;
      userId = userId;
      scheduledAt = input.scheduledAt;
      duration = input.duration;
      var topic = input.topic;
      var notes = input.notes;
      var status = #pending;
      var meetLink = null;
      createdAt = Time.now();
    };
    bookings.add(booking);
    toBookingPublic(booking);
  };

  public func listBookings(
    bookings : List.List<CommunityTypes.CallBooking>,
    userId : Common.UserId,
  ) : [CommunityTypes.CallBookingPublic] {
    let result = List.empty<CommunityTypes.CallBookingPublic>();
    for (b in bookings.values()) {
      if (Principal.equal(b.userId, userId)) {
        result.add(toBookingPublic(b));
      };
    };
    result.toArray();
  };

  public func createAnnouncement(
    announcements : List.List<CommunityTypes.Announcement>,
    adminId : Common.UserId,
    input : CommunityTypes.CreateAnnouncementInput,
  ) : CommunityTypes.AnnouncementPublic {
    let id = "announce-" # adminId.toText() # "-" # Time.now().toText();
    let now = Time.now();
    let announcement : CommunityTypes.Announcement = {
      id = id;
      adminId = adminId;
      title = input.title;
      body = input.body;
      var plan = input.plan;
      var emailSent = false;
      sentAt = now;
    };
    announcements.add(announcement);
    toAnnouncementPublic(announcement);
  };

  public func listAnnouncements(
    announcements : List.List<CommunityTypes.Announcement>,
  ) : [CommunityTypes.AnnouncementPublic] {
    let result = List.empty<CommunityTypes.AnnouncementPublic>();
    for (a in announcements.values()) {
      result.add(toAnnouncementPublic(a));
    };
    result.toArray();
  };

  public func createLiveSession(
    sessions : List.List<CommunityTypes.LiveSession>,
    adminId : Common.UserId,
    input : CommunityTypes.CreateLiveSessionInput,
  ) : CommunityTypes.LiveSessionPublic {
    let id = "session-" # adminId.toText() # "-" # Time.now().toText();
    let session : CommunityTypes.LiveSession = {
      id = id;
      var title = input.title;
      var description = input.description;
      var scheduledAt = input.scheduledAt;
      var joinUrl = input.joinUrl;
      var recordingUrl = null;
      var tags = input.tags;
      var status = #upcoming;
      createdAt = Time.now();
    };
    sessions.add(session);
    toSessionPublic(session);
  };

  public func listLiveSessions(
    sessions : List.List<CommunityTypes.LiveSession>,
  ) : [CommunityTypes.LiveSessionPublic] {
    let result = List.empty<CommunityTypes.LiveSessionPublic>();
    for (s in sessions.values()) {
      result.add(toSessionPublic(s));
    };
    result.toArray();
  };

  public func toMentorCommentPublic(mc : CommunityTypes.MentorComment) : CommunityTypes.MentorCommentPublic {
    {
      id = mc.id;
      tradeId = mc.tradeId;
      adminId = mc.adminId;
      comment = mc.comment;
      createdAt = mc.createdAt;
    };
  };

  public func createMentorComment(
    comments : Map.Map<Text, CommunityTypes.MentorComment>,
    adminId : Common.UserId,
    tradeId : Text,
    comment : Text,
  ) : CommunityTypes.MentorCommentPublic {
    let id = "mc-" # tradeId;
    let mc : CommunityTypes.MentorComment = {
      id = id;
      tradeId = tradeId;
      adminId = adminId;
      var comment = comment;
      createdAt = Time.now();
    };
    comments.add(tradeId, mc);
    toMentorCommentPublic(mc);
  };

  public func getMentorComment(
    comments : Map.Map<Text, CommunityTypes.MentorComment>,
    tradeId : Text,
  ) : ?CommunityTypes.MentorCommentPublic {
    switch (comments.get(tradeId)) {
      case (?mc) ?toMentorCommentPublic(mc);
      case null null;
    };
  };
};
