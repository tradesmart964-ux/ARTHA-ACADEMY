import List "mo:core/List";
import Map "mo:core/Map";
import Time "mo:core/Time";
import Principal "mo:core/Principal";
import Common "../types/common";
import TradingTypes "../types/trading";

module {
  public func toAccountPublic(acc : TradingTypes.TradingAccount) : TradingTypes.TradingAccountPublic {
    {
      id = acc.id;
      userId = acc.userId;
      name = acc.name;
      broker = acc.broker;
      accountNumber = acc.accountNumber;
      accountType = acc.accountType;
      propFirm = acc.propFirm;
      phase = acc.phase;
      startingBalance = acc.startingBalance;
      currentBalance = acc.currentBalance;
      currency = acc.currency;
      profitTarget = acc.profitTarget;
      dailyDDLimit = acc.dailyDDLimit;
      maxDDLimit = acc.maxDDLimit;
      minTradingDays = acc.minTradingDays;
      startDate = acc.startDate;
      endDate = acc.endDate;
      status = acc.status;
      isPrimary = acc.isPrimary;
      createdAt = acc.createdAt;
    };
  };

  public func toTradePublic(trade : TradingTypes.Trade) : TradingTypes.TradePublic {
    {
      id = trade.id;
      userId = trade.userId;
      accountId = trade.accountId;
      dateTime = trade.dateTime;
      pair = trade.pair;
      direction = trade.direction;
      entryPrice = trade.entryPrice;
      exitPrice = trade.exitPrice;
      stopLoss = trade.stopLoss;
      takeProfit = trade.takeProfit;
      lotSize = trade.lotSize;
      accountBal = trade.accountBal;
      riskAmount = trade.riskAmount;
      riskPercent = trade.riskPercent;
      rrRatio = trade.rrRatio;
      grossPnl = trade.grossPnl;
      netPnl = trade.netPnl;
      result = trade.result;
      session = trade.session;
      strategy = trade.strategy;
      emotion = trade.emotion;
      followedPlan = trade.followedPlan;
      notes = trade.notes;
      screenshotUrl = trade.screenshotUrl;
      mistakes = trade.mistakes;
      createdAt = trade.createdAt;
    };
  };

  public func createAccount(
    accounts : Map.Map<Text, TradingTypes.TradingAccount>,
    userId : Common.UserId,
    input : TradingTypes.CreateAccountInput,
  ) : TradingTypes.TradingAccountPublic {
    let id = "acc-" # userId.toText() # "-" # Time.now().toText();
    let acc : TradingTypes.TradingAccount = {
      id = id;
      userId = userId;
      var name = input.name;
      var broker = input.broker;
      var accountNumber = input.accountNumber;
      accountType = input.accountType;
      var propFirm = input.propFirm;
      var phase = input.phase;
      startingBalance = input.startingBalance;
      var currentBalance = input.startingBalance;
      var currency = input.currency;
      var profitTarget = input.profitTarget;
      var dailyDDLimit = input.dailyDDLimit;
      var maxDDLimit = input.maxDDLimit;
      var minTradingDays = input.minTradingDays;
      var startDate = null;
      var endDate = null;
      var status = "ACTIVE";
      var isPrimary = false;
      createdAt = Time.now();
    };
    accounts.add(id, acc);
    toAccountPublic(acc);
  };

  public func listAccounts(
    accounts : Map.Map<Text, TradingTypes.TradingAccount>,
    userId : Common.UserId,
  ) : [TradingTypes.TradingAccountPublic] {
    let result = List.empty<TradingTypes.TradingAccountPublic>();
    for ((_, acc) in accounts.entries()) {
      if (Principal.equal(acc.userId, userId)) {
        result.add(toAccountPublic(acc));
      };
    };
    result.toArray();
  };

  public func createTrade(
    trades : List.List<TradingTypes.Trade>,
    userId : Common.UserId,
    input : TradingTypes.CreateTradeInput,
  ) : TradingTypes.TradePublic {
    let id = "trade-" # userId.toText() # "-" # Time.now().toText();
    let trade : TradingTypes.Trade = {
      id = id;
      userId = userId;
      var accountId = input.accountId;
      dateTime = input.dateTime;
      pair = input.pair;
      direction = input.direction;
      entryPrice = input.entryPrice;
      var exitPrice = input.exitPrice;
      var stopLoss = input.stopLoss;
      var takeProfit = input.takeProfit;
      var lotSize = input.lotSize;
      var accountBal = input.accountBal;
      var riskAmount = input.riskAmount;
      var riskPercent = input.riskPercent;
      var rrRatio = input.rrRatio;
      var grossPnl = input.grossPnl;
      var netPnl = input.netPnl;
      var result = input.result;
      var session = input.session;
      var strategy = input.strategy;
      var emotion = input.emotion;
      var followedPlan = input.followedPlan;
      var notes = input.notes;
      var screenshotUrl = input.screenshotUrl;
      var mistakes = input.mistakes;
      createdAt = Time.now();
    };
    trades.add(trade);
    toTradePublic(trade);
  };

  public func getTrade(
    trades : List.List<TradingTypes.Trade>,
    id : Text,
  ) : ?TradingTypes.TradePublic {
    switch (trades.find(func(t) = t.id == id)) {
      case (?t) ?toTradePublic(t);
      case null null;
    };
  };

  public func listTrades(
    trades : List.List<TradingTypes.Trade>,
    userId : Common.UserId,
  ) : [TradingTypes.TradePublic] {
    let result = List.empty<TradingTypes.TradePublic>();
    for (t in trades.values()) {
      if (Principal.equal(t.userId, userId)) {
        result.add(toTradePublic(t));
      };
    };
    result.toArray();
  };

  public func deleteTrade(
    trades : List.List<TradingTypes.Trade>,
    id : Text,
    userId : Common.UserId,
  ) : Bool {
    switch (trades.findIndex(func(t) = t.id == id and Principal.equal(t.userId, userId))) {
      case (?idx) {
        let before = trades.sliceToArray(0, idx);
        let after = trades.sliceToArray(idx + 1, trades.size().toInt());
        trades.clear();
        for (item in before.values()) {
          trades.add(item);
        };
        for (item in after.values()) {
          trades.add(item);
        };
        true;
      };
      case null false;
    };
  };

  public func listAllTrades(
    trades : List.List<TradingTypes.Trade>,
  ) : [TradingTypes.TradePublic] {
    let result = List.empty<TradingTypes.TradePublic>();
    for (t in trades.values()) {
      result.add(toTradePublic(t));
    };
    result.toArray();
  };
};
