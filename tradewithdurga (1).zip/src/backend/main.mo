import Map "mo:core/Map";
import List "mo:core/List";
import Principal "mo:core/Principal";
import Time "mo:core/Time";
import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import Common "types/common";
import UserTypes "types/users";
import TradingTypes "types/trading";
import AnalyticsTypes "types/analytics";
import CommunityTypes "types/community";
import UserLib "lib/users";
import UsersMixin "mixins/users-api";
import TradingMixin "mixins/trading-api";
import AnalyticsMixin "mixins/analytics-api";
import CommunityMixin "mixins/community-api";

actor {
  // Authorization
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  // User state
  let users = Map.empty<Common.UserId, UserTypes.User>();
  let emailIndex = Map.empty<Text, Common.UserId>();
  include UsersMixin(accessControlState, users, emailIndex);

  // Trading state
  let accounts = Map.empty<Text, TradingTypes.TradingAccount>();
  let trades = List.empty<TradingTypes.Trade>();
  include TradingMixin(accessControlState, accounts, trades);

  // Analytics state
  let uploads = List.empty<AnalyticsTypes.DailyUpload>();
  let backtests = List.empty<AnalyticsTypes.BacktestSession>();
  let payouts = List.empty<AnalyticsTypes.Payout>();
  let consistencyRecords = List.empty<AnalyticsTypes.ConsistencyRecord>();
  include AnalyticsMixin(accessControlState, uploads, backtests, payouts, consistencyRecords);

  // Community state
  let forumThreads = List.empty<CommunityTypes.ForumThread>();
  let forumReplies = List.empty<CommunityTypes.ForumReply>();
  let bookings = List.empty<CommunityTypes.CallBooking>();
  let announcements = List.empty<CommunityTypes.Announcement>();
  let liveSessions = List.empty<CommunityTypes.LiveSession>();
  let mentorComments = Map.empty<Text, CommunityTypes.MentorComment>();
  include CommunityMixin(accessControlState, forumThreads, forumReplies, bookings, announcements, liveSessions, mentorComments);

  // Seed demo users on first deploy (idempotent)
  let _adminId = Principal.fromText("aaaaa-aa");
  let _studentId = Principal.fromText("2vxsx-fae");
  UserLib.seedUsers(users, emailIndex, _adminId, _studentId);

  // Seed a demo trading account and sample trades for the student on first deploy
  do {
    if (not accounts.containsKey("acc-demo-student")) {
      let demoAcc : TradingTypes.TradingAccount = {
        id = "acc-demo-student";
        userId = _studentId;
        var name = "Demo FTMO Account";
        var broker = ?"FTMO";
        var accountNumber = ?"DEMO-001";
        accountType = #funded;
        var propFirm = ?"FTMO";
        var phase = ?"Phase 1";
        startingBalance = 10000.0;
        var currentBalance = 10450.0;
        var currency = "USD";
        var profitTarget = ?10.0;
        var dailyDDLimit = ?5.0;
        var maxDDLimit = ?10.0;
        var minTradingDays = ?4;
        var startDate = ?(Time.now() - 8 * 24 * 3600 * 1_000_000_000);
        var endDate = null;
        var status = "ACTIVE";
        var isPrimary = true;
        createdAt = Time.now() - 8 * 24 * 3600 * 1_000_000_000;
      };
      accounts.add("acc-demo-student", demoAcc);

      // Add 3 sample trades
      let t1 : TradingTypes.Trade = {
        id = "trade-demo-1";
        userId = _studentId;
        var accountId = ?"acc-demo-student";
        dateTime = Time.now() - 7 * 24 * 3600 * 1_000_000_000;
        pair = "EUR/USD";
        direction = #buy;
        entryPrice = 1.0850;
        var exitPrice = ?1.0920;
        var stopLoss = ?1.0810;
        var takeProfit = ?1.0930;
        var lotSize = ?0.5;
        var accountBal = ?10000.0;
        var riskAmount = ?40.0;
        var riskPercent = ?0.4;
        var rrRatio = ?1.75;
        var grossPnl = ?70.0;
        var netPnl = ?68.5;
        var result = ?#win;
        var session = ?#london;
        var strategy = ?"ICT";
        var emotion = ?"Calm";
        var followedPlan = ?true;
        var notes = ?"Clean break of structure, followed plan.";
        var screenshotUrl = null;
        var mistakes = [];
        createdAt = Time.now() - 7 * 24 * 3600 * 1_000_000_000;
      };
      let t2 : TradingTypes.Trade = {
        id = "trade-demo-2";
        userId = _studentId;
        var accountId = ?"acc-demo-student";
        dateTime = Time.now() - 5 * 24 * 3600 * 1_000_000_000;
        pair = "GBP/USD";
        direction = #sell;
        entryPrice = 1.2650;
        var exitPrice = ?1.2590;
        var stopLoss = ?1.2690;
        var takeProfit = ?1.2570;
        var lotSize = ?0.3;
        var accountBal = ?10068.5;
        var riskAmount = ?12.0;
        var riskPercent = ?0.12;
        var rrRatio = ?2.0;
        var grossPnl = ?24.0;
        var netPnl = ?22.8;
        var result = ?#win;
        var session = ?#ny;
        var strategy = ?"Price Action";
        var emotion = ?"Confident";
        var followedPlan = ?true;
        var notes = ?"NY session sell with SMT divergence.";
        var screenshotUrl = null;
        var mistakes = [];
        createdAt = Time.now() - 5 * 24 * 3600 * 1_000_000_000;
      };
      let t3 : TradingTypes.Trade = {
        id = "trade-demo-3";
        userId = _studentId;
        var accountId = ?"acc-demo-student";
        dateTime = Time.now() - 2 * 24 * 3600 * 1_000_000_000;
        pair = "XAU/USD";
        direction = #buy;
        entryPrice = 2310.0;
        var exitPrice = ?2295.0;
        var stopLoss = ?2300.0;
        var takeProfit = ?2340.0;
        var lotSize = ?0.1;
        var accountBal = ?10091.3;
        var riskAmount = ?100.0;
        var riskPercent = ?0.99;
        var rrRatio = ?3.0;
        var grossPnl = ?-150.0;
        var netPnl = ?-151.5;
        var result = ?#loss;
        var session = ?#london;
        var strategy = ?"ICT";
        var emotion = ?"FOMO";
        var followedPlan = ?false;
        var notes = ?"Entered too early, stop hit.";
        var screenshotUrl = null;
        var mistakes = ["Chased entry"];
        createdAt = Time.now() - 2 * 24 * 3600 * 1_000_000_000;
      };
      trades.add(t1);
      trades.add(t2);
      trades.add(t3);

      // Seed a sample live session
      let demoSession : CommunityTypes.LiveSession = {
        id = "session-demo-1";
        var title = "London Kill Zone Analysis — Live Q&A";
        var description = ?"Live market analysis covering GBP/USD and EUR/USD SMT divergence setups during London open.";
        var scheduledAt = Time.now() + 2 * 24 * 3600 * 1_000_000_000;
        var joinUrl = ?"https://zoom.us/j/demo-session";
        var recordingUrl = null;
        var tags = ["Analysis", "Q&A", "London"];
        var status = #upcoming;
        createdAt = Time.now();
      };
      liveSessions.add(demoSession);
    };
  };
};
