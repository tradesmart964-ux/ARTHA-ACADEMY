import Common "common";

module {
  public type DailyUpload = {
    id : Text;
    userId : Common.UserId;
    var accountId : ?Text;
    tradingDate : Common.Timestamp;
    var csvUrl : ?Text;
    var totalTrades : Nat;
    var winCount : Nat;
    var lossCount : Nat;
    var grossPnl : ?Float;
    var netPnl : ?Float;
    var dailyDD : ?Float;
    var maxDD : ?Float;
    var avgRiskPercent : ?Float;
    var riskBreachCount : Nat;
    var dailyDDBreached : Bool;
    var maxDDBreached : Bool;
    var parsedData : ?Text; // JSON as text
    createdAt : Common.Timestamp;
  };

  public type DailyUploadPublic = {
    id : Text;
    userId : Common.UserId;
    accountId : ?Text;
    tradingDate : Common.Timestamp;
    csvUrl : ?Text;
    totalTrades : Nat;
    winCount : Nat;
    lossCount : Nat;
    grossPnl : ?Float;
    netPnl : ?Float;
    dailyDD : ?Float;
    maxDD : ?Float;
    avgRiskPercent : ?Float;
    riskBreachCount : Nat;
    dailyDDBreached : Bool;
    maxDDBreached : Bool;
    parsedData : ?Text;
    createdAt : Common.Timestamp;
  };

  public type CreateUploadInput = {
    accountId : ?Text;
    tradingDate : Common.Timestamp;
    csvUrl : ?Text;
    totalTrades : Nat;
    winCount : Nat;
    lossCount : Nat;
    grossPnl : ?Float;
    netPnl : ?Float;
    dailyDD : ?Float;
    maxDD : ?Float;
    avgRiskPercent : ?Float;
    riskBreachCount : Nat;
    dailyDDBreached : Bool;
    maxDDBreached : Bool;
    parsedData : ?Text;
  };

  public type BacktestSession = {
    id : Text;
    userId : Common.UserId;
    var name : Text;
    var pair : Text;
    var timeframe : Text;
    startingBalance : Float;
    var riskPerTrade : ?Float;
    var dateRangeStart : ?Common.Timestamp;
    var dateRangeEnd : ?Common.Timestamp;
    var totalTrades : Nat;
    var winRate : ?Float;
    var netPnl : ?Float;
    var maxDD : ?Float;
    var profitFactor : ?Float;
    var avgRR : ?Float;
    var tradeLog : ?Text; // JSON as text
    createdAt : Common.Timestamp;
  };

  public type BacktestSessionPublic = {
    id : Text;
    userId : Common.UserId;
    name : Text;
    pair : Text;
    timeframe : Text;
    startingBalance : Float;
    riskPerTrade : ?Float;
    dateRangeStart : ?Common.Timestamp;
    dateRangeEnd : ?Common.Timestamp;
    totalTrades : Nat;
    winRate : ?Float;
    netPnl : ?Float;
    maxDD : ?Float;
    profitFactor : ?Float;
    avgRR : ?Float;
    tradeLog : ?Text;
    createdAt : Common.Timestamp;
  };

  public type CreateBacktestInput = {
    name : Text;
    pair : Text;
    timeframe : Text;
    startingBalance : Float;
    riskPerTrade : ?Float;
    dateRangeStart : ?Common.Timestamp;
    dateRangeEnd : ?Common.Timestamp;
    totalTrades : Nat;
    winRate : ?Float;
    netPnl : ?Float;
    maxDD : ?Float;
    profitFactor : ?Float;
    avgRR : ?Float;
    tradeLog : ?Text;
  };

  public type ConsistencyRecord = {
    id : Text;
    userId : Common.UserId;
    date : Common.Timestamp;
    score : Float;
    greenDayRatio : Float;
    winRate : Float;
    riskDiscipline : Float;
    streak : Nat;
    createdAt : Common.Timestamp;
  };

  public type Payout = {
    id : Text;
    userId : Common.UserId;
    var accountId : ?Text;
    payoutDate : Common.Timestamp;
    amount : Float;
    currency : Text;
    payoutType : Text;
    var profitSplitPct : ?Float;
    var actualReceived : ?Float;
    var status : Common.PayoutStatus;
    var paymentMethod : ?Text;
    var proofUrl : ?Text;
    var notes : ?Text;
    createdAt : Common.Timestamp;
  };

  public type PayoutPublic = {
    id : Text;
    userId : Common.UserId;
    accountId : ?Text;
    payoutDate : Common.Timestamp;
    amount : Float;
    currency : Text;
    payoutType : Text;
    profitSplitPct : ?Float;
    actualReceived : ?Float;
    status : Common.PayoutStatus;
    paymentMethod : ?Text;
    proofUrl : ?Text;
    notes : ?Text;
    createdAt : Common.Timestamp;
  };

  public type CreatePayoutInput = {
    accountId : ?Text;
    payoutDate : Common.Timestamp;
    amount : Float;
    currency : Text;
    payoutType : Text;
    profitSplitPct : ?Float;
    paymentMethod : ?Text;
    notes : ?Text;
  };
};
