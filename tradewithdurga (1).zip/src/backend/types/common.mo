module {
  public type Timestamp = Int; // nanoseconds from Time.now()
  public type UserId = Principal;

  public type Role = {
    #admin;
    #student;
  };

  public type Plan = {
    #free;
    #silver;
    #gold;
    #platinum;
  };

  public type AccountType = {
    #funded;
    #live;
    #demo;
  };

  public type TradeDirection = {
    #buy;
    #sell;
  };

  public type TradeResult = {
    #win;
    #loss;
    #breakeven;
  };

  public type TradeSession = {
    #london;
    #ny;
    #asian;
    #overlap;
  };

  public type PayoutStatus = {
    #pending;
    #paid;
    #rejected;
  };

  public type LiveSessionStatus = {
    #upcoming;
    #live;
    #ended;
  };

  public type CallBookingStatus = {
    #pending;
    #confirmed;
    #cancelled;
    #completed;
  };
};
