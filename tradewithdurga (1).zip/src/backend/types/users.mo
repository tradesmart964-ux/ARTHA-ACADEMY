import Common "common";

module {
  public type User = {
    id : Common.UserId;
    var name : Text;
    email : Text;
    var passwordHash : Text;
    var role : Common.Role;
    var plan : Common.Plan;
    var avatar : ?Text;
    var bio : ?Text;
    var phone : ?Text;
    var country : ?Text;
    var timezone : ?Text;
    var experience : ?Text;
    createdAt : Common.Timestamp;
  };

  // Public (shared) type - no var fields
  public type UserPublic = {
    id : Common.UserId;
    name : Text;
    email : Text;
    role : Common.Role;
    plan : Common.Plan;
    avatar : ?Text;
    bio : ?Text;
    phone : ?Text;
    country : ?Text;
    timezone : ?Text;
    experience : ?Text;
    createdAt : Common.Timestamp;
  };

  public type CreateUserInput = {
    name : Text;
    email : Text;
    passwordHash : Text;
    role : Common.Role;
    plan : Common.Plan;
  };

  public type UpdateUserInput = {
    name : ?Text;
    avatar : ?Text;
    bio : ?Text;
    phone : ?Text;
    country : ?Text;
    timezone : ?Text;
    experience : ?Text;
  };
};
