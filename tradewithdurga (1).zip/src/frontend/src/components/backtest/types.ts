// Shared types for backtest components
export interface OHLCCandle {
  time: number; // Unix timestamp
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export type TradeLineKind = "entry" | "sl" | "tp";

export interface TradeLine {
  price: number;
  kind: TradeLineKind;
}

export interface ActiveTrade {
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  lotSize: number;
  entryCandle: number; // index in candles array
}

export type BacktestPhase = "idle" | "running" | "entry" | "complete";

export interface SessionConfig {
  name: string;
  pair: string;
  timeframe: string;
  startingBalance: number;
  riskPerTrade: number;
}

export interface BacktestTradeLog {
  id: string;
  entryPrice: number;
  exitPrice: number;
  stopLoss: number;
  takeProfit: number;
  lotSize: number;
  result: "WIN" | "LOSS" | "BREAKEVEN";
  pnl: number;
  rrRatio: number;
  candleIndex: number;
}

export interface SessionResults {
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  netPnl: number;
  maxDD: number;
  profitFactor: number;
  avgRR: number;
  tradeLog: BacktestTradeLog[];
  equityCurve: { index: number; balance: number }[];
}

export interface SavedSession {
  id: string;
  name: string;
  pair: string;
  timeframe: string;
  startingBalance: number;
  createdAt: string;
  results: SessionResults;
}
