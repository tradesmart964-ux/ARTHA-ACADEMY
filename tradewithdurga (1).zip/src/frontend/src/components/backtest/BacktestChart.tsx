import {
  type CandlestickData,
  CandlestickSeries,
  CrosshairMode,
  type IChartApi,
  type ISeriesApi,
  LineStyle,
  type Time,
  createChart,
} from "lightweight-charts";
import { useCallback, useEffect, useRef } from "react";
import type { OHLCCandle, TradeLine } from "./types";

interface BacktestChartProps {
  candles: OHLCCandle[];
  visibleCount: number;
  tradeLines: TradeLine[];
  onChartReady?: (chart: IChartApi) => void;
}

export function BacktestChart({
  candles,
  visibleCount,
  tradeLines,
  onChartReady,
}: BacktestChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const onChartReadyRef = useRef(onChartReady);
  onChartReadyRef.current = onChartReady;

  const initChart = useCallback(() => {
    if (!containerRef.current) return undefined;

    const chart = createChart(containerRef.current, {
      layout: {
        background: { color: "#0A0A0F" },
        textColor: "#8888A0",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "rgba(255,255,255,0.04)" },
        horzLines: { color: "rgba(255,255,255,0.04)" },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: "rgba(255,255,255,0.3)",
          labelBackgroundColor: "#111118",
        },
        horzLine: {
          color: "rgba(255,255,255,0.3)",
          labelBackgroundColor: "#111118",
        },
      },
      rightPriceScale: {
        borderColor: "rgba(255,255,255,0.06)",
      },
      timeScale: {
        borderColor: "rgba(255,255,255,0.06)",
        timeVisible: true,
      },
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
    });

    // lightweight-charts v5: chart.addSeries(SeriesDefinition, options)
    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: "#4ADE80",
      downColor: "#F87171",
      borderUpColor: "#22C55E",
      borderDownColor: "#EF4444",
      wickUpColor: "#22C55E",
      wickDownColor: "#EF4444",
    });

    chartRef.current = chart;
    candleSeriesRef.current = candleSeries;

    const resizeObserver = new ResizeObserver(() => {
      if (containerRef.current) {
        chart.applyOptions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        });
      }
    });
    resizeObserver.observe(containerRef.current);

    onChartReadyRef.current?.(chart);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
      candleSeriesRef.current = null;
    };
  }, []);

  useEffect(() => {
    return initChart();
  }, [initChart]);

  // Update visible candle data
  useEffect(() => {
    if (!candleSeriesRef.current) return;
    const visible = candles.slice(0, visibleCount);
    const data: CandlestickData<Time>[] = visible.map((c) => ({
      time: c.time as Time,
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close,
    }));
    candleSeriesRef.current.setData(data);
    if (chartRef.current && data.length > 0) {
      chartRef.current.timeScale().fitContent();
    }
  }, [candles, visibleCount]);

  // Draw/update trade lines as price lines on the series
  useEffect(() => {
    if (!candleSeriesRef.current) return;
    // Remove all price lines by recreating them
    // lightweight-charts v4 doesn't expose a "removeAllPriceLines" so we track via state in parent
    // Here we apply by setting the price lines after clearing
    const series = candleSeriesRef.current;
    for (const line of tradeLines) {
      const color =
        line.kind === "entry"
          ? "#89AACC"
          : line.kind === "sl"
            ? "#F87171"
            : "#4ADE80";
      series.createPriceLine({
        price: line.price,
        color,
        lineWidth: 1,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: line.kind.toUpperCase(),
      });
    }
  }, [tradeLines]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full"
      data-ocid="backtest.canvas_target"
      aria-label="Backtest candlestick chart"
    />
  );
}
