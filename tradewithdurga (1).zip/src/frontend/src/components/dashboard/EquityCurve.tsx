import { GlassCard } from "@/components/GlassCard";
import type { IChartApi } from "lightweight-charts";
import { motion } from "motion/react";
import { useEffect, useRef, useState } from "react";

type Timeframe = "1W" | "1M" | "3M" | "1Y" | "ALL";
type EquityPoint = { time: string; value: number };

function generateEquityData(days: number): EquityPoint[] {
  const data: EquityPoint[] = [];
  let val = 10000;
  const now = new Date();
  for (let i = days; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const change = (Math.random() - 0.42) * 80;
    val = Math.max(9000, val + change);
    data.push({
      time: d.toISOString().split("T")[0] as string,
      value: Math.round(val * 100) / 100,
    });
  }
  data[data.length - 1].value = 10450;
  return data;
}

const timeframeMap: Record<Timeframe, number> = {
  "1W": 7,
  "1M": 30,
  "3M": 90,
  "1Y": 365,
  ALL: 730,
};

export function EquityCurve({ loading = false }: { loading?: boolean }) {
  const [active, setActive] = useState<Timeframe>("1M");
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstanceRef = useRef<IChartApi | null>(null);

  useEffect(() => {
    if (loading || !chartRef.current) return;
    let destroyed = false;

    import("lightweight-charts").then(({ createChart, LineSeries }) => {
      if (destroyed || !chartRef.current) return;
      if (chartInstanceRef.current) {
        chartInstanceRef.current.remove();
        chartInstanceRef.current = null;
      }

      const chart = createChart(chartRef.current, {
        width: chartRef.current.clientWidth,
        height: 240,
        layout: {
          background: { color: "transparent" },
          textColor: "#8888A0",
        },
        grid: {
          vertLines: { color: "rgba(255,255,255,0.04)" },
          horzLines: { color: "rgba(255,255,255,0.04)" },
        },
        crosshair: { mode: 1 },
        rightPriceScale: { borderColor: "rgba(255,255,255,0.06)" },
        timeScale: { borderColor: "rgba(255,255,255,0.06)", timeVisible: true },
        handleScroll: false,
        handleScale: false,
      });

      chartInstanceRef.current = chart;

      const series = chart.addSeries(LineSeries, {
        color: "#89AACC",
        lineWidth: 2,
        priceLineVisible: false,
        lastValueVisible: true,
        crosshairMarkerVisible: true,
        crosshairMarkerRadius: 4,
        crosshairMarkerBackgroundColor: "#89AACC",
      });

      series.setData(generateEquityData(timeframeMap[active]));
      chart.timeScale().fitContent();

      const ro = new ResizeObserver(() => {
        if (chartRef.current)
          chart.applyOptions({ width: chartRef.current.clientWidth });
      });
      ro.observe(chartRef.current);
      return () => ro.disconnect();
    });

    return () => {
      destroyed = true;
      if (chartInstanceRef.current) {
        chartInstanceRef.current.remove();
        chartInstanceRef.current = null;
      }
    };
  }, [active, loading]);

  if (loading) return <div className="rounded-2xl h-80 skeleton" />;

  return (
    <GlassCard className="p-5" data-ocid="equity_curve.card">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <h3 className="text-sm font-semibold text-foreground">
            Equity Curve
          </h3>
          <p className="text-xs mt-0.5" style={{ color: "#8888A0" }}>
            Account balance over time
          </p>
        </div>
        <div
          className="flex items-center gap-1 rounded-xl p-1"
          style={{ background: "rgba(255,255,255,0.04)" }}
        >
          {(["1W", "1M", "3M", "1Y", "ALL"] as Timeframe[]).map((tf) => (
            <button
              key={tf}
              type="button"
              data-ocid={`equity_curve.${tf.toLowerCase()}.tab`}
              onClick={() => setActive(tf)}
              className="px-3 py-1 rounded-lg text-xs font-medium transition-all duration-200"
              style={
                active === tf
                  ? {
                      background:
                        "linear-gradient(135deg, #89AACC 0%, #4E85BF 100%)",
                      color: "#0A0A0F",
                    }
                  : { color: "#8888A0" }
              }
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      <motion.div
        key={active}
        initial={{ opacity: 0, clipPath: "inset(0 100% 0 0)" }}
        animate={{ opacity: 1, clipPath: "inset(0 0% 0 0)" }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <div ref={chartRef} className="w-full" style={{ minHeight: 240 }} />
      </motion.div>
    </GlassCard>
  );
}
