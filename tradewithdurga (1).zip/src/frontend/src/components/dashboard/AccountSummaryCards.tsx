import { GlassCard } from "@/components/GlassCard";
import { useEffect, useRef, useState } from "react";
import { Area, AreaChart, ResponsiveContainer } from "recharts";

const sparklineData = [
  { v: 10100 },
  { v: 10050 },
  { v: 10200 },
  { v: 10180 },
  { v: 10250 },
  { v: 10320 },
  { v: 10290 },
  { v: 10380 },
  { v: 10420 },
  { v: 10450 },
];

function useAnimatedNumber(target: number, duration = 1200, decimals = 2) {
  const [value, setValue] = useState(0);
  const rafRef = useRef<number | null>(null);
  useEffect(() => {
    const start = performance.now();
    const animate = (now: number) => {
      const t = Math.min((now - start) / duration, 1);
      const ease = 1 - (1 - t) ** 3;
      setValue(Number.parseFloat((ease * target).toFixed(decimals)));
      if (t < 1) rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [target, duration, decimals]);
  return value;
}

function DrawdownBar({ pct, limit }: { pct: number; limit: number }) {
  const ratio = Math.min(pct / limit, 1);
  const color = ratio < 0.6 ? "#4ADE80" : ratio < 0.8 ? "#FBBF24" : "#F87171";
  return (
    <div
      className="w-full h-1.5 rounded-full mt-1"
      style={{ background: "rgba(255,255,255,0.08)" }}
    >
      <div
        className="h-full rounded-full transition-all duration-1000"
        style={{ width: `${ratio * 100}%`, background: color }}
      />
    </div>
  );
}

interface Props {
  loading?: boolean;
}

export function AccountSummaryCards({ loading = false }: Props) {
  const totalBalance = useAnimatedNumber(10450, 1200, 2);
  const totalPnl = useAnimatedNumber(2840, 1300, 2);
  const totalPct = useAnimatedNumber(38.5, 1300, 1);
  const todayPnl = useAnimatedNumber(240, 1100, 2);
  const drawdown = useAnimatedNumber(2.4, 1200, 1);

  if (loading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {["c1", "c2", "c3", "c4"].map((k) => (
          <div key={k} className="rounded-2xl h-36 skeleton" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Card 1: Total Balance */}
      <GlassCard accentTop className="p-5 flex flex-col gap-3">
        <p
          className="text-xs uppercase tracking-widest"
          style={{ color: "#8888A0" }}
        >
          Total Balance
        </p>
        <p className="text-2xl font-semibold tabular-nums text-foreground">
          $
          {totalBalance.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}
        </p>
        <p className="text-xs font-medium" style={{ color: "#4ADE80" }}>
          +$240 today
        </p>
        <div className="h-10 mt-auto">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={sparklineData}
              margin={{ top: 2, right: 0, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#89AACC" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#89AACC" stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area
                type="monotone"
                dataKey="v"
                stroke="#89AACC"
                strokeWidth={1.5}
                fill="url(#sparkGrad)"
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>

      {/* Card 2: Total P&L All Time */}
      <GlassCard accentTop className="p-5 flex flex-col gap-3">
        <p
          className="text-xs uppercase tracking-widest"
          style={{ color: "#8888A0" }}
        >
          Total P&L All Time
        </p>
        <p
          className="text-2xl font-semibold tabular-nums"
          style={{ color: "#4ADE80" }}
        >
          +$
          {totalPnl.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}
        </p>
        <p className="text-sm font-medium" style={{ color: "#4ADE80" }}>
          +{totalPct}% return
        </p>
        <div className="mt-auto">
          <div className="flex items-center gap-2">
            <div
              className="w-2 h-2 rounded-full"
              style={{ background: "#4ADE80" }}
            />
            <span className="text-xs" style={{ color: "#8888A0" }}>
              All time profit
            </span>
          </div>
        </div>
      </GlassCard>

      {/* Card 3: Today's P&L */}
      <GlassCard accentTop className="p-5 flex flex-col gap-3">
        <p
          className="text-xs uppercase tracking-widest"
          style={{ color: "#8888A0" }}
        >
          Today's P&L
        </p>
        <p
          className="text-2xl font-semibold tabular-nums"
          style={{ color: "#4ADE80" }}
        >
          +$
          {todayPnl.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })}
        </p>
        <p className="text-xs" style={{ color: "#8888A0" }}>
          vs yesterday
        </p>
        <div className="mt-auto flex items-center gap-1.5">
          <div
            className="w-1.5 h-1.5 rounded-full animate-pulse"
            style={{ background: "#4ADE80" }}
          />
          <span className="text-xs" style={{ color: "#4ADE80" }}>
            Profitable day
          </span>
        </div>
      </GlassCard>

      {/* Card 4: Open Drawdown */}
      <GlassCard accentTop className="p-5 flex flex-col gap-3">
        <p
          className="text-xs uppercase tracking-widest"
          style={{ color: "#8888A0" }}
        >
          Open Drawdown
        </p>
        <p className="text-2xl font-semibold tabular-nums text-foreground">
          {drawdown}%
        </p>
        <DrawdownBar pct={2.4} limit={5} />
        <p className="text-xs" style={{ color: "#8888A0" }}>
          of 5% daily limit
        </p>
        <div className="mt-auto">
          <span
            className="text-xs px-2 py-0.5 rounded-full"
            style={{ background: "rgba(74,222,128,0.12)", color: "#4ADE80" }}
          >
            ✅ Safe
          </span>
        </div>
      </GlassCard>
    </div>
  );
}
