import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type Timestamp = bigint;
export interface UserPublic {
    id: UserId;
    bio?: string;
    timezone?: string;
    country?: string;
    name: string;
    createdAt: Timestamp;
    plan: Plan;
    role: Role;
    email: string;
    experience?: string;
    phone?: string;
    avatar?: string;
}
export interface CallBookingPublic {
    id: string;
    status: CallBookingStatus;
    topic?: string;
    duration: bigint;
    meetLink?: string;
    userId: UserId;
    createdAt: Timestamp;
    notes?: string;
    scheduledAt: Timestamp;
}
export interface CreateForumThreadInput {
    title: string;
    body: string;
    imageUrl?: string;
    category: string;
}
export interface ForumReplyPublic {
    id: string;
    body: string;
    userId: UserId;
    createdAt: Timestamp;
    threadId: string;
    parentId?: string;
}
export interface CreateLiveSessionInput {
    title: string;
    tags: Array<string>;
    joinUrl?: string;
    description?: string;
    scheduledAt: Timestamp;
}
export interface CreateBookingInput {
    topic?: string;
    duration: bigint;
    notes?: string;
    scheduledAt: Timestamp;
}
export interface CreatePayoutInput {
    paymentMethod?: string;
    accountId?: string;
    profitSplitPct?: number;
    currency: string;
    notes?: string;
    amount: number;
    payoutDate: Timestamp;
    payoutType: string;
}
export interface ConsistencyRecord {
    id: string;
    streak: bigint;
    userId: UserId;
    date: Timestamp;
    createdAt: Timestamp;
    score: number;
    greenDayRatio: number;
    riskDiscipline: number;
    winRate: number;
}
export interface TradingAccountPublic {
    id: string;
    status: string;
    broker?: string;
    endDate?: Timestamp;
    currentBalance: number;
    userId: UserId;
    name: string;
    createdAt: Timestamp;
    minTradingDays?: bigint;
    isPrimary: boolean;
    accountType: AccountType;
    propFirm?: string;
    currency: string;
    profitTarget?: number;
    dailyDDLimit?: number;
    startingBalance: number;
    accountNumber?: string;
    phase?: string;
    maxDDLimit?: number;
    startDate?: Timestamp;
}
export interface DailyUploadPublic {
    id: string;
    maxDD?: number;
    totalTrades: bigint;
    dailyDDBreached: boolean;
    csvUrl?: string;
    accountId?: string;
    userId: UserId;
    riskBreachCount: bigint;
    createdAt: Timestamp;
    lossCount: bigint;
    parsedData?: string;
    grossPnl?: number;
    netPnl?: number;
    avgRiskPercent?: number;
    winCount: bigint;
    dailyDD?: number;
    tradingDate: Timestamp;
    maxDDBreached: boolean;
}
export interface LiveSessionPublic {
    id: string;
    status: LiveSessionStatus;
    title: string;
    recordingUrl?: string;
    createdAt: Timestamp;
    tags: Array<string>;
    joinUrl?: string;
    description?: string;
    scheduledAt: Timestamp;
}
export interface CreateAnnouncementInput {
    title: string;
    body: string;
    plan?: Plan;
}
export interface UpdateUserInput {
    bio?: string;
    timezone?: string;
    country?: string;
    name?: string;
    experience?: string;
    phone?: string;
    avatar?: string;
}
export interface TradePublic {
    id: string;
    accountBal?: number;
    result?: TradeResult;
    direction: TradeDirection;
    accountId?: string;
    riskPercent?: number;
    emotion?: string;
    userId: UserId;
    riskAmount?: number;
    strategy?: string;
    takeProfit?: number;
    screenshotUrl?: string;
    createdAt: Timestamp;
    pair: string;
    grossPnl?: number;
    mistakes: Array<string>;
    netPnl?: number;
    followedPlan?: boolean;
    rrRatio?: number;
    session?: TradeSession;
    stopLoss?: number;
    notes?: string;
    entryPrice: number;
    exitPrice?: number;
    dateTime: Timestamp;
    lotSize?: number;
}
export interface CreateUserInput {
    name: string;
    plan: Plan;
    role: Role;
    email: string;
    passwordHash: string;
}
export interface ForumThreadPublic {
    id: string;
    title: string;
    solved: boolean;
    body: string;
    userId: UserId;
    createdAt: Timestamp;
    bookmarks: bigint;
    likes: bigint;
    imageUrl?: string;
    category: string;
}
export interface CreateTradeInput {
    accountBal?: number;
    result?: TradeResult;
    direction: TradeDirection;
    accountId?: string;
    riskPercent?: number;
    emotion?: string;
    riskAmount?: number;
    strategy?: string;
    takeProfit?: number;
    screenshotUrl?: string;
    pair: string;
    grossPnl?: number;
    mistakes: Array<string>;
    netPnl?: number;
    followedPlan?: boolean;
    rrRatio?: number;
    session?: TradeSession;
    stopLoss?: number;
    notes?: string;
    entryPrice: number;
    exitPrice?: number;
    dateTime: Timestamp;
    lotSize?: number;
}
export interface PayoutPublic {
    id: string;
    actualReceived?: number;
    status: PayoutStatus;
    paymentMethod?: string;
    proofUrl?: string;
    accountId?: string;
    profitSplitPct?: number;
    userId: UserId;
    createdAt: Timestamp;
    currency: string;
    notes?: string;
    amount: number;
    payoutDate: Timestamp;
    payoutType: string;
}
export interface AnnouncementPublic {
    id: string;
    title: string;
    body: string;
    plan?: Plan;
    sentAt: Timestamp;
    emailSent: boolean;
    adminId: UserId;
}
export interface BacktestSessionPublic {
    id: string;
    maxDD?: number;
    totalTrades: bigint;
    tradeLog?: string;
    avgRR?: number;
    timeframe: string;
    riskPerTrade?: number;
    userId: UserId;
    name: string;
    createdAt: Timestamp;
    pair: string;
    dateRangeStart?: Timestamp;
    netPnl?: number;
    dateRangeEnd?: Timestamp;
    startingBalance: number;
    winRate?: number;
    profitFactor?: number;
}
export type UserId = Principal;
export interface CreateBacktestInput {
    maxDD?: number;
    totalTrades: bigint;
    tradeLog?: string;
    avgRR?: number;
    timeframe: string;
    riskPerTrade?: number;
    name: string;
    pair: string;
    dateRangeStart?: Timestamp;
    netPnl?: number;
    dateRangeEnd?: Timestamp;
    startingBalance: number;
    winRate?: number;
    profitFactor?: number;
}
export interface CreateAccountInput {
    broker?: string;
    name: string;
    minTradingDays?: bigint;
    accountType: AccountType;
    propFirm?: string;
    currency: string;
    profitTarget?: number;
    dailyDDLimit?: number;
    startingBalance: number;
    accountNumber?: string;
    phase?: string;
    maxDDLimit?: number;
}
export interface CreateForumReplyInput {
    body: string;
    threadId: string;
    parentId?: string;
}
export interface CreateUploadInput {
    maxDD?: number;
    totalTrades: bigint;
    dailyDDBreached: boolean;
    csvUrl?: string;
    accountId?: string;
    riskBreachCount: bigint;
    lossCount: bigint;
    parsedData?: string;
    grossPnl?: number;
    netPnl?: number;
    avgRiskPercent?: number;
    winCount: bigint;
    dailyDD?: number;
    tradingDate: Timestamp;
    maxDDBreached: boolean;
}
export interface MentorCommentPublic {
    id: string;
    createdAt: Timestamp;
    comment: string;
    tradeId: string;
    adminId: UserId;
}
export enum AccountType {
    demo = "demo",
    live = "live",
    funded = "funded"
}
export enum CallBookingStatus {
    cancelled = "cancelled",
    pending = "pending",
    completed = "completed",
    confirmed = "confirmed"
}
export enum LiveSessionStatus {
    upcoming = "upcoming",
    live = "live",
    ended = "ended"
}
export enum PayoutStatus {
    pending = "pending",
    paid = "paid",
    rejected = "rejected"
}
export enum Plan {
    free = "free",
    gold = "gold",
    platinum = "platinum",
    silver = "silver"
}
export enum Role {
    admin = "admin",
    student = "student"
}
export enum TradeDirection {
    buy = "buy",
    sell = "sell"
}
export enum TradeResult {
    win = "win",
    loss = "loss",
    breakeven = "breakeven"
}
export enum TradeSession {
    ny = "ny",
    asian = "asian",
    london = "london",
    overlap = "overlap"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addMentorComment(tradeId: string, comment: string): Promise<MentorCommentPublic>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    createAccount(input: CreateAccountInput): Promise<TradingAccountPublic>;
    createAnnouncement(input: CreateAnnouncementInput): Promise<AnnouncementPublic>;
    createBacktest(input: CreateBacktestInput): Promise<BacktestSessionPublic>;
    createBooking(input: CreateBookingInput): Promise<CallBookingPublic>;
    createForumReply(input: CreateForumReplyInput): Promise<ForumReplyPublic>;
    createForumThread(input: CreateForumThreadInput): Promise<ForumThreadPublic>;
    createLiveSession(input: CreateLiveSessionInput): Promise<LiveSessionPublic>;
    createPayout(input: CreatePayoutInput): Promise<PayoutPublic>;
    createTrade(input: CreateTradeInput): Promise<TradePublic>;
    createUpload(input: CreateUploadInput): Promise<DailyUploadPublic>;
    createUser(input: CreateUserInput): Promise<UserPublic>;
    deleteTrade(id: string): Promise<boolean>;
    getCallerUserProfile(): Promise<UserPublic | null>;
    getCallerUserRole(): Promise<UserRole>;
    getConsistency(): Promise<ConsistencyRecord | null>;
    getMentorComment(tradeId: string): Promise<MentorCommentPublic | null>;
    getTrade(id: string): Promise<TradePublic | null>;
    getUser(id: UserId): Promise<UserPublic | null>;
    isCallerAdmin(): Promise<boolean>;
    listAccounts(): Promise<Array<TradingAccountPublic>>;
    listAllTrades(): Promise<Array<TradePublic>>;
    listAllUploads(): Promise<Array<DailyUploadPublic>>;
    listAnnouncements(): Promise<Array<AnnouncementPublic>>;
    listBacktests(): Promise<Array<BacktestSessionPublic>>;
    listBookings(): Promise<Array<CallBookingPublic>>;
    listForumThreads(): Promise<Array<ForumThreadPublic>>;
    listLiveSessions(): Promise<Array<LiveSessionPublic>>;
    listPayouts(): Promise<Array<PayoutPublic>>;
    listRepliesByThread(threadId: string): Promise<Array<ForumReplyPublic>>;
    listTrades(): Promise<Array<TradePublic>>;
    listUploads(): Promise<Array<DailyUploadPublic>>;
    listUsers(): Promise<Array<UserPublic>>;
    seedInitialUsers(): Promise<void>;
    updateUser(input: UpdateUserInput): Promise<UserPublic | null>;
    updateUserPlan(userId: UserId, plan: Plan): Promise<UserPublic | null>;
}
